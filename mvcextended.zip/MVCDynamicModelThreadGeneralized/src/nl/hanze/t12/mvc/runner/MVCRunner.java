package nl.hanze.t12.mvc.runner;

import nl.hanze.t12.mvc.main.*;

public class MVCRunner {
	public static void main(String[] args) {
		new MVCDDynamicModelThreadGeneralized();
	}
}
