package nl.hanze.t12.mvc;

public class MVCRunner {
	public static void main(String[] args) {
		new MVCDynamicModelNoThread();
	}
}
