package nl.hanze.t12.life.runner;

import nl.hanze.t12.life.main.*;

public class LifeRunner {
	public static void main(String[] args) {
		new Life();
	}
}
